# Campus Discovery App
Purpose of this project is to create an app which will allow administrators at various universities to host events for users to attend. They will be given the ability to create events, edit event details, allow RSVPs, and notify students who sign up. Users can pick and choose which events to save and RSVP to.

